#include "TGA.h"
#include <fstream>
TGA::Header::Header()
{
	idLenght = '0';
	colorMapType = '0';
	dataTypeCode = '0';
	colorMapOrigin = 0;
	colorMapLength = 0;
	colorMapDepth = '0';
	xOrigin = 0;
	yOrigin = 0;
	width = 0;
	height = 0;
	bitsPerPixel = '0';
	imageDescriptor = '0';
}
TGA::TGA()
{
	Header imageHeader;
	vector<Pixel*> imagePixels;
}
TGA::TGA(Header& imageHeader, vector<Pixel*>& imagePixels)
{
	this->imageHeader = imageHeader;
	this->imagePixels = imagePixels;
}
TGA::TGA(const TGA& other)
{
	this->imageHeader = other.imageHeader;
	this->imagePixels = other.imagePixels;
}
TGA& TGA::operator=(const TGA& other)
{
	this->imageHeader = other.imageHeader;
	this->imagePixels = other.imagePixels;
	return *this;
}
TGA::~TGA()
{
	imagePixels.clear();
}

Pixel::Pixel()
{
	red = '0';
	green = '0';
	blue = '0';
}


