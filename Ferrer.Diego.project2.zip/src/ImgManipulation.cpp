#include "ImgManipulation.h"
#include "TGA.h"
#include <fstream>
void ReadTGAFile(TGA& someTGA, const string& tgaFile)
{
	ifstream tga(tgaFile, ios_base::binary);
	//Read all the information of the header 

	tga.read(&someTGA.imageHeader.idLenght, sizeof(someTGA.imageHeader.idLenght));
	tga.read(&someTGA.imageHeader.colorMapType, sizeof(someTGA.imageHeader.colorMapType));
	tga.read(&someTGA.imageHeader.dataTypeCode, sizeof(someTGA.imageHeader.dataTypeCode));
	tga.read((char*)&someTGA.imageHeader.colorMapOrigin, sizeof(someTGA.imageHeader.colorMapOrigin));
	tga.read((char*)&someTGA.imageHeader.colorMapLength, sizeof(someTGA.imageHeader.colorMapLength));
	tga.read(&someTGA.imageHeader.colorMapDepth, sizeof(someTGA.imageHeader.colorMapDepth));
	tga.read((char*)&someTGA.imageHeader.xOrigin, sizeof(someTGA.imageHeader.xOrigin));
	tga.read((char*)&someTGA.imageHeader.yOrigin, sizeof(someTGA.imageHeader.yOrigin));
	tga.read((char*)&someTGA.imageHeader.width, sizeof(someTGA.imageHeader.width));
	tga.read((char*)&someTGA.imageHeader.height, sizeof(someTGA.imageHeader.height));
	tga.read(&someTGA.imageHeader.bitsPerPixel, sizeof(someTGA.imageHeader.bitsPerPixel));
	tga.read(&someTGA.imageHeader.imageDescriptor, sizeof(someTGA.imageHeader.imageDescriptor));


	int totalImageBytes = someTGA.imageHeader.height * someTGA.imageHeader.width;
	//read RGB (BGR) of each pixel
	for (int i = 0; i < totalImageBytes; i++)
	{
		//Pixel* px = new Pixel();
		Pixel* px = new Pixel();
		tga.read((char*)&px->blue, sizeof(px->blue));
		tga.read((char*)&px->green, sizeof(px->green));
		tga.read((char*)&px->red, sizeof(px->red));
		someTGA.imagePixels.push_back(px);
	}

}
void WriteTGAFile(TGA& someTGA, const string& tgaFile)
{
	//
	ofstream tga(tgaFile, ios_base::binary);
	//Read all the information of the header 
	tga.write(&someTGA.imageHeader.idLenght, sizeof(someTGA.imageHeader.idLenght));
	tga.write(&someTGA.imageHeader.colorMapType, sizeof(someTGA.imageHeader.colorMapType));
	tga.write(&someTGA.imageHeader.dataTypeCode, sizeof(someTGA.imageHeader.dataTypeCode));
	tga.write((char*)&someTGA.imageHeader.colorMapOrigin, sizeof(someTGA.imageHeader.colorMapOrigin));
	tga.write((char*)&someTGA.imageHeader.colorMapLength, sizeof(someTGA.imageHeader.colorMapLength));
	tga.write(&someTGA.imageHeader.colorMapDepth, sizeof(someTGA.imageHeader.colorMapDepth));
	tga.write((char*)&someTGA.imageHeader.xOrigin, sizeof(someTGA.imageHeader.xOrigin));
	tga.write((char*)&someTGA.imageHeader.yOrigin, sizeof(someTGA.imageHeader.yOrigin));
	tga.write((char*)&someTGA.imageHeader.width, sizeof(someTGA.imageHeader.width));
	tga.write((char*)&someTGA.imageHeader.height, sizeof(someTGA.imageHeader.height));
	tga.write(&someTGA.imageHeader.bitsPerPixel, sizeof(someTGA.imageHeader.bitsPerPixel));
	tga.write(&someTGA.imageHeader.imageDescriptor, sizeof(someTGA.imageHeader.imageDescriptor));


	int totalImageBytes = someTGA.imageHeader.height * someTGA.imageHeader.width;
	//read RGB (BGR) of each pixel
	for (int i = 0; i < totalImageBytes; i++)
	{
		tga.write((char*)&someTGA.imagePixels.at(i)->blue, sizeof(someTGA.imagePixels.at(i)->blue));
		tga.write((char*)&someTGA.imagePixels.at(i)->green, sizeof(someTGA.imagePixels.at(i)->green));
		tga.write((char*)&someTGA.imagePixels.at(i)->red, sizeof(someTGA.imagePixels.at(i)->red));
	}
}
void Multiply(TGA& top, TGA& bottom, TGA& result)
{
	vector<Pixel*> blendedPixels;

	int topImageBytes = top.imageHeader.height * top.imageHeader.width;
	int bottomImageBytes = bottom.imageHeader.height * bottom.imageHeader.width;

	if (topImageBytes == bottomImageBytes)
	{
		for (int i = 0; i < topImageBytes; i++) //multiply pixel values
		{
			Pixel* px = new Pixel();
			//Blue
			float blendedBlue = (static_cast<float>(top.imagePixels.at(i)->blue)* static_cast<float>(bottom.imagePixels.at(i)->blue)) / 255.0f;
			blendedBlue += 0.5f;
			unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
			px->blue = bluePx;

			//Green
			float blendedGreen = (static_cast<float>(top.imagePixels.at(i)->green)* static_cast<float>(bottom.imagePixels.at(i)->green)) / 255.0f;
			blendedGreen += 0.5f;
			unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
			px->green = greenPx;

			//Red
			float blendedRed = (static_cast<float>(top.imagePixels.at(i)->red)* static_cast<float>(bottom.imagePixels.at(i)->red)) / 255.0f;
			blendedRed += 0.5f;
			unsigned char redPx = static_cast<unsigned char>(blendedRed);
			px->red = redPx;

			blendedPixels.push_back(px);
		}
	}

	result = TGA(top.imageHeader, blendedPixels);

	
}
void Subtract(TGA& top, TGA& bottom, TGA& result)
{

	vector<Pixel*> blendedPixels;

	int topImageBytes = top.imageHeader.height * top.imageHeader.width;
	int bottomImageBytes = bottom.imageHeader.height * bottom.imageHeader.width;

	if (topImageBytes == bottomImageBytes)
	{
		for (int i = 0; i < topImageBytes; i++) //subtract pixel values
		{
			Pixel* px = new Pixel();
			//Blue
			int blendedBlue = static_cast<int>(bottom.imagePixels.at(i)->blue) - static_cast<int>(top.imagePixels.at(i)->blue);
			if (blendedBlue > 255)
			{
				blendedBlue = 255;
			}
			else if(blendedBlue < 0)
			{
				blendedBlue = 0;
			}
			unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
			px->blue = bluePx;

			//Green
			int blendedGreen = static_cast<int>(bottom.imagePixels.at(i)->green) - static_cast<int>(top.imagePixels.at(i)->green);
			if (blendedGreen > 255)
			{
				blendedGreen = 255;
			}
			else if (blendedGreen < 0)
			{
				blendedGreen = 0;
			}
			unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
			px->green = greenPx;

			//Red
			int blendedRed = static_cast<int>(bottom.imagePixels.at(i)->red) - static_cast<int>(top.imagePixels.at(i)->red);
			if (blendedRed > 255)
			{
				blendedRed = 255;
			}
			else if (blendedRed < 0)
			{
				blendedRed = 0;
			}
			unsigned char redPx = static_cast<unsigned char>(blendedRed);
			px->red = redPx;

			blendedPixels.push_back(px);
		}
	}

	result = TGA(top.imageHeader, blendedPixels);

}
void Screen(TGA& top, TGA& bottom, TGA& result)
{
	vector<Pixel*> blendedPixels;

	int topImageBytes = top.imageHeader.height * top.imageHeader.width;
	int bottomImageBytes = bottom.imageHeader.height * bottom.imageHeader.width;

	if (topImageBytes == bottomImageBytes)
	{
		for (int i = 0; i < topImageBytes; i++) //multiply pixel values
		{
			Pixel* px = new Pixel();
			//Blue
			float blendedBlue = (1 - (1- (static_cast<float>(top.imagePixels.at(i)->blue)/255.0f))*(1- (static_cast<float>(bottom.imagePixels.at(i)->blue)/255.0f)))*255.0f;
			blendedBlue += 0.5f;
			unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
			px->blue = bluePx;

			//Green
			float blendedGreen = (1 - (1 - (static_cast<float>(top.imagePixels.at(i)->green) / 255.0f))* (1 - (static_cast<float>(bottom.imagePixels.at(i)->green) / 255.0f))) * 255.0f;
			blendedGreen += 0.5f;
			unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
			px->green = greenPx;

			//Red
			float blendedRed = (1 - (1 - (static_cast<float>(top.imagePixels.at(i)->red) / 255.0f))* (1 - (static_cast<float>(bottom.imagePixels.at(i)->red) / 255.0f))) * 255.0f;;
			blendedRed += 0.5f;
			unsigned char redPx = static_cast<unsigned char>(blendedRed);
			px->red = redPx;

			blendedPixels.push_back(px);
		}
	}

	result = TGA(top.imageHeader, blendedPixels);
}
void Overlay(TGA& top, TGA& bottom, TGA& result)
{
	vector<Pixel*> blendedPixels;

	int topImageBytes = top.imageHeader.height * top.imageHeader.width;
	int bottomImageBytes = bottom.imageHeader.height * bottom.imageHeader.width;

	if (topImageBytes == bottomImageBytes)
	{
		for (int i = 0; i < topImageBytes; i++)
		{
			Pixel* px = new Pixel();

			//Blue
			float blueVal = (static_cast<float>(bottom.imagePixels.at(i)->blue) / 255.0f);
			if (blueVal <= 0.5)
			{
				float blendedBlue = 2.0f*((static_cast<float>(top.imagePixels.at(i)->blue)* static_cast<float>(bottom.imagePixels.at(i)->blue)) / 255.0f);
				blendedBlue += 0.5f;
				if (blendedBlue > 255.0f)
				{
					blendedBlue = 255.0f;
					unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
					px->blue = bluePx;
				}
				else if (blendedBlue < 0.0f)
				{
					blendedBlue = 0.0f;
					unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
					px->blue = bluePx;
				}
				else
				{
					unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
					px->blue = bluePx;
				}
			}
			else if (blueVal > 0.5)
			{
				float blendedBlue = (1 - 2*((1 -(static_cast<float>(top.imagePixels.at(i)->blue) / 255.0f))* (1 - (static_cast<float>(bottom.imagePixels.at(i)->blue) / 255.0f)))) * 255.0f;
				blendedBlue += 0.5f;
				if (blendedBlue < 0.0f)
				{
					blendedBlue = 0.0f;
					unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
					px->blue = bluePx;
				}
				else
				{
					unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
					px->blue = bluePx;
				}
			}

			//Green
			float greenVal = (static_cast<float>(bottom.imagePixels.at(i)->green) / 255.0f);
			if (greenVal <= 0.5)
			{
				float blendedGreen = 2.0f * ((static_cast<float>(top.imagePixels.at(i)->green)* static_cast<float>(bottom.imagePixels.at(i)->green)) / 255.0f);
				blendedGreen += 0.5f;
				if (blendedGreen > 255.0f)
				{
					blendedGreen = 255.0f;
					unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
					px->green = greenPx;
				}
				else if (blendedGreen < 0.0f)
				{
					blendedGreen = 0.0f;
					unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
					px->green = greenPx;
				}
				else
				{
					unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
					px->green = greenPx;
				}
			}
			else if (greenVal > 0.5)
			{
				float blendedGreen = (1 - 2 * ((1 - (static_cast<float>(top.imagePixels.at(i)->green) / 255.0f))* (1 - (static_cast<float>(bottom.imagePixels.at(i)->green) / 255.0f)))) * 255.0f;
				blendedGreen += 0.5f;
				if (blendedGreen < 0.0f)
				{
					blendedGreen = 0.0f;
					unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
					px->green = greenPx;
				}
				else
				{
					unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
					px->green = greenPx;
				}
			}

			//Red
			float redVal = (static_cast<float>(bottom.imagePixels.at(i)->red) / 255.0f);
			if (redVal <= 0.5)
			{
				float blendedRed = 2.0f * ((static_cast<float>(top.imagePixels.at(i)->red)* static_cast<float>(bottom.imagePixels.at(i)->red)) / 255.0f);
				blendedRed += 0.5f;
				if (blendedRed > 255.0f)
				{
					blendedRed = 255.0f;
					unsigned char redPx = static_cast<unsigned char>(blendedRed);
					px->red = redPx;
				}
				else if (blendedRed < 0.0f)
				{
					blendedRed = 0.0f;
					unsigned char redPx = static_cast<unsigned char>(blendedRed);
					px->red = redPx;
				}
				else
				{
					unsigned char redPx = static_cast<unsigned char>(blendedRed);
					px->red = redPx;
				}
			}
			else if (redVal > 0.5)
			{
				float blendedRed = (1 - 2 * ((1 - (static_cast<float>(top.imagePixels.at(i)->red) / 255.0f))* (1 - (static_cast<float>(bottom.imagePixels.at(i)->red) / 255.0f)))) * 255.0f;
				blendedRed += 0.5f;
				if (blendedRed < 0.0f)
				{
					blendedRed = 0.0f;
					unsigned char redPx = static_cast<unsigned char>(blendedRed);
					px->red = redPx;
				}
				else
				{
					unsigned char redPx = static_cast<unsigned char>(blendedRed);
					px->red = redPx;
				}
			}
			blendedPixels.push_back(px);
		}
	}

	result = TGA(top.imageHeader, blendedPixels);
}
void AddToChannel(TGA& image, TGA& result,const string& channel, int increment)
{
	vector<Pixel*> blendedPixels;
	int imageBytes = image.imageHeader.height * image.imageHeader.width;
	if (channel == "blue")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			int blendedBlue = static_cast<int>(image.imagePixels.at(i)->blue) + increment;
			if (blendedBlue > 255)
			{
				blendedBlue = 255;
			}
			else if (blendedBlue < 0)
			{
				blendedBlue = 0;
			}
			unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
			px->blue = bluePx;
			px->green = image.imagePixels.at(i)->green;
			px->red = image.imagePixels.at(i)->red;

			blendedPixels.push_back(px);
		}
		
	}
	if (channel == "green")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			int blendedGreen = static_cast<int>(image.imagePixels.at(i)->green) + increment;
			if (blendedGreen > 255)
			{
				blendedGreen = 255;
			}
			else if (blendedGreen < 0)
			{
				blendedGreen = 0;
			}
			unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
			px->blue = image.imagePixels.at(i)->blue;
			px->green = greenPx;
			px->red = image.imagePixels.at(i)->red;

			blendedPixels.push_back(px);
		}

	}
	if (channel == "red")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			int blendedRed = static_cast<int>(image.imagePixels.at(i)->red) + increment;
			if (blendedRed > 255)
			{
				blendedRed = 255;
			}
			else if (blendedRed < 0)
			{
				blendedRed= 0;
			}
			unsigned char redPx = static_cast<unsigned char>(blendedRed);
			px->blue = image.imagePixels.at(i)->blue;
			px->green = image.imagePixels.at(i)->green;
			px->red = redPx;

			blendedPixels.push_back(px);
		}

	}

	result = TGA(image.imageHeader, blendedPixels);
}
void ScaleChannel(TGA& image, TGA& result, const string& channel, int increment)
{
	vector<Pixel*> blendedPixels;
	int imageBytes = image.imageHeader.height * image.imageHeader.width;
	if (channel == "blue")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			float blendedBlue = static_cast<float>(image.imagePixels.at(i)->blue) * increment;
			if (blendedBlue > 255.0f)
			{
				blendedBlue = 255.0f;
			}
			else if (blendedBlue < 0.0f)
			{
				blendedBlue = 0.0f;
			}
			unsigned char bluePx = static_cast<unsigned char>(blendedBlue);
			px->blue = bluePx;
			px->green = image.imagePixels.at(i)->green;
			px->red = image.imagePixels.at(i)->red;

			blendedPixels.push_back(px);
		}

	}
	if (channel == "green")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			px->blue == image.imagePixels.at(i)->blue;
			float blendedGreen = static_cast<float>(image.imagePixels.at(i)->green) * increment;
			if (blendedGreen > 255.0f)
			{
				blendedGreen = 255.0f;
			}
			else if (blendedGreen < 0.0f)
			{
				blendedGreen = 0.0f;
			}
			unsigned char greenPx = static_cast<unsigned char>(blendedGreen);
			px->green = greenPx;
			px->red = image.imagePixels.at(i)->red;

			blendedPixels.push_back(px);
		}

	}
	if (channel == "red")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			px->blue == image.imagePixels.at(i)->blue;
			px->green = image.imagePixels.at(i)->green;
			float blendedRed = static_cast<float>(image.imagePixels.at(i)->red) * increment;
			if (blendedRed > 255.0f)
			{
				blendedRed = 255.0f;
			}
			else if (blendedRed < 0.0f)
			{
				blendedRed = 0.0f;
			}
			unsigned char redPx = static_cast<unsigned char>(blendedRed);
			px->red = redPx;

			blendedPixels.push_back(px);
		}

	}

	result = TGA(image.imageHeader, blendedPixels);
}
void SetChannelEqual(TGA& image, TGA& result, const string& channel)
{
	vector<Pixel*> blendedPixels;
	int imageBytes = image.imageHeader.height * image.imageHeader.width;
	if (channel == "blue")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			px->blue = image.imagePixels.at(i)->blue;
			px->green = image.imagePixels.at(i)->blue;
			px->red = image.imagePixels.at(i)->blue;

			blendedPixels.push_back(px);
		}

	}
	if (channel == "green")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			px->blue = image.imagePixels.at(i)->green;
			px->green = image.imagePixels.at(i)->green;
			px->red = image.imagePixels.at(i)->green;

			blendedPixels.push_back(px);
		}

	}
	if (channel == "red")
	{
		for (int i = 0; i < imageBytes; i++)
		{
			Pixel* px = new Pixel();
			px->blue = image.imagePixels.at(i)->red;
			px->green = image.imagePixels.at(i)->red;
			px->red = image.imagePixels.at(i)->red;

			blendedPixels.push_back(px);
		}

	}

	result = TGA(image.imageHeader, blendedPixels);
}
void BuildFromLayers(TGA& blueLayer, TGA& greenLayer, TGA& redLayer, TGA& result) 
{
	vector<Pixel*> blendedPixels;

	int blueLayerBytes = blueLayer.imageHeader.height * blueLayer.imageHeader.width;
	int greenLayerBytes = greenLayer.imageHeader.height * greenLayer.imageHeader.width;
	int redLayerBytes = redLayer.imageHeader.height * redLayer.imageHeader.width;

	if ((blueLayerBytes == greenLayerBytes) && (blueLayerBytes == redLayerBytes))
	{
		for (int i = 0; i < blueLayerBytes; i++)
		{
			Pixel* px = new Pixel();
			px->blue = blueLayer.imagePixels.at(i)->blue;
			px->green = greenLayer.imagePixels.at(i)->green;
			px->red = redLayer.imagePixels.at(i)->red;
			blendedPixels.push_back(px);
		}
	}

	result = TGA(blueLayer.imageHeader, blendedPixels);
}
void WriteReverse(TGA& someTGA, const string& tgaFile)
{
	ofstream tga(tgaFile, ios_base::binary);
	//Read all the information of the header 
	tga.write(&someTGA.imageHeader.idLenght, sizeof(someTGA.imageHeader.idLenght));
	tga.write(&someTGA.imageHeader.colorMapType, sizeof(someTGA.imageHeader.colorMapType));
	tga.write(&someTGA.imageHeader.dataTypeCode, sizeof(someTGA.imageHeader.dataTypeCode));
	tga.write((char*)&someTGA.imageHeader.colorMapOrigin, sizeof(someTGA.imageHeader.colorMapOrigin));
	tga.write((char*)&someTGA.imageHeader.colorMapLength, sizeof(someTGA.imageHeader.colorMapLength));
	tga.write(&someTGA.imageHeader.colorMapDepth, sizeof(someTGA.imageHeader.colorMapDepth));
	tga.write((char*)&someTGA.imageHeader.xOrigin, sizeof(someTGA.imageHeader.xOrigin));
	tga.write((char*)&someTGA.imageHeader.yOrigin, sizeof(someTGA.imageHeader.yOrigin));
	tga.write((char*)&someTGA.imageHeader.width, sizeof(someTGA.imageHeader.width));
	tga.write((char*)&someTGA.imageHeader.height, sizeof(someTGA.imageHeader.height));
	tga.write(&someTGA.imageHeader.bitsPerPixel, sizeof(someTGA.imageHeader.bitsPerPixel));
	tga.write(&someTGA.imageHeader.imageDescriptor, sizeof(someTGA.imageHeader.imageDescriptor));


	int totalImageBytes = someTGA.imageHeader.height * someTGA.imageHeader.width;
	//read RGB (BGR) of each pixel
	for (int i = (totalImageBytes-1); i >= 0; i--) //Write in reverse order
	{
		tga.write((char*)&someTGA.imagePixels.at(i)->blue, sizeof(someTGA.imagePixels.at(i)->blue));
		tga.write((char*)&someTGA.imagePixels.at(i)->green, sizeof(someTGA.imagePixels.at(i)->green));
		tga.write((char*)&someTGA.imagePixels.at(i)->red, sizeof(someTGA.imagePixels.at(i)->red));
	}
}
void CombineImages(TGA& a, TGA& b, TGA& c, TGA& d, TGA& result)
{
	vector<Pixel*> blendedPixels;

	int expandedWidth = a.imageHeader.width + b.imageHeader.width;
	int expandedHeigth = c.imageHeader.height + b.imageHeader.height;
	int imageBytes = expandedHeigth * expandedWidth;
	
	//Create the image and fill it with blank pixels
	for (int i = 0; i < imageBytes; i++)
	{
		Pixel* px = new Pixel();
		px->blue = '0';
		px->green = '0';
		px->red = '0';
		blendedPixels.push_back(px);
	}

	//Fill the first quadrant with image a
	int firstQuadrantLimit = ((imageBytes) / 2) - a.imageHeader.width;
	int lineTracker = 0;
	for (int i = 0; i < firstQuadrantLimit; i += expandedWidth)
	{
		for (int j = i; j < (i+(expandedWidth/2)); j++)
		{
			blendedPixels.at(j)->blue = a.imagePixels.at(lineTracker)->blue;
			blendedPixels.at(j)->green = a.imagePixels.at(lineTracker)->green;
			blendedPixels.at(j)->red = a.imagePixels.at(lineTracker)->red;
			lineTracker++;
		}
	}
	//Fill the second quadrant with image b
	int seconQuadrantLimit = ((imageBytes) / 2);
	lineTracker = 0;
	for (int i = (expandedWidth/2); i < seconQuadrantLimit; i += expandedWidth)
	{
		for (int j = i; j < (i + 512); j++)
		{
			blendedPixels.at(j)->blue = b.imagePixels.at(lineTracker)->blue;
			blendedPixels.at(j)->green = b.imagePixels.at(lineTracker)->green;
			blendedPixels.at(j)->red = b.imagePixels.at(lineTracker)->red;
			lineTracker++;
		}
	}
	//Fill the thrid quadrant with image c
	int thirdQuadrantLimit = imageBytes - 512;
	lineTracker = 0;
	for (int i = (imageBytes/2); i < thirdQuadrantLimit; i += expandedWidth)
	{
		for (int j = i; j < (i + (expandedWidth/2)); j++)
		{
			blendedPixels.at(j)->blue = c.imagePixels.at(lineTracker)->blue;
			blendedPixels.at(j)->green = c.imagePixels.at(lineTracker)->green;
			blendedPixels.at(j)->red = c.imagePixels.at(lineTracker)->red;
			lineTracker++;
		}
	}
	//Fill the fourth quadrant with image d
	int fourthQuadrantLimit = imageBytes;
	lineTracker = 0;
	for (int i = ((imageBytes / 2)+(expandedWidth/2)); i < fourthQuadrantLimit; i += expandedWidth)
	{
		for (int j = i; j < (i + (expandedWidth/2)); j++)
		{
			blendedPixels.at(j)->blue = d.imagePixels.at(lineTracker)->blue;
			blendedPixels.at(j)->green = d.imagePixels.at(lineTracker)->green;
			blendedPixels.at(j)->red = d.imagePixels.at(lineTracker)->red;
			lineTracker++;
		}
	}
	a.imageHeader.width = expandedWidth;
	a.imageHeader.height = expandedHeigth;
	result = TGA(a.imageHeader, blendedPixels);
}