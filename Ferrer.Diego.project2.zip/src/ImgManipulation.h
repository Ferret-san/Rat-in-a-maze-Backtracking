#pragma once
#include "TGA.h"
#include <string>
using namespace std;

void ReadTGAFile(TGA& someTGA, const string& tgaFile);
void WriteTGAFile(TGA& someTGA, const string& tgaFile);
//Blending modes
void Multiply(TGA& top, TGA& bottom, TGA& result); 
void Subtract(TGA& top, TGA& bottom, TGA& result);
void Screen(TGA& top, TGA& bottom, TGA& result);
void Overlay(TGA& top, TGA& bottom, TGA& result);
//Change the channel R, G, or B of a file
void AddToChannel(TGA& image,TGA& result, const string& channel, int increment);
void ScaleChannel(TGA& image, TGA& result, const string& channel, int increment);
void SetChannelEqual(TGA& image, TGA& result, const string& channel);
void BuildFromLayers(TGA& blueLayer, TGA& greenLayer, TGA& redLayer, TGA& result);
void WriteReverse(TGA& someTGA, const string& tgaFile);
void CombineImages(TGA& a, TGA& b, TGA& c, TGA& d, TGA& result);
