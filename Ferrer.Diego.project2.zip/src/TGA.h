#pragma once
#include <vector>
using namespace std;
//Structure for a pixel of RGB content, TGA files store it as BGR
struct Pixel
{
	//Make Adjustments to Make Pixel structure Pointer efficient (Add the big three)
	unsigned char red;
	unsigned char green;
	unsigned char blue;
	Pixel();
};
struct TGA
{
		//Structure for the 18 bytes of information in the header
		struct Header
		{
			char idLenght;
			char colorMapType;
			char dataTypeCode;
			short colorMapOrigin;
			short colorMapLength;
			char colorMapDepth;
			short xOrigin;
			short yOrigin;
			short width;
			short height;
			char bitsPerPixel;
			char imageDescriptor;
			Header();
		};
		

	TGA();
	TGA(Header& imageHeader, vector<Pixel*>& imagePixels);
	TGA(const TGA& other);
	TGA& operator=(const TGA& other);
	~TGA();
	
	vector<Pixel*> imagePixels; //All the pixels in an image = to height x width
	Header imageHeader;
};

