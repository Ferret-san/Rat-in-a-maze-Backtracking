#include "TGA.h"
#include "ImgManipulation.h"
#include <iostream>
using namespace std;
int main()
{
	//part 1
	TGA layer1;
	TGA pattern1;
	TGA part1;
	ReadTGAFile(layer1, "input/layer1.tga");
	ReadTGAFile(pattern1, "input/pattern1.tga");
	Multiply(layer1, pattern1, part1);
	WriteTGAFile(part1, "output/part1.tga");
	//part 2
	TGA layer2;
	TGA car;
	TGA part2;
	ReadTGAFile(layer2, "input/layer2.tga");
	ReadTGAFile(car, "input/car.tga");
	Subtract(layer2, car, part2);
	WriteTGAFile(part2, "output/part2.tga");
	//part 3
	TGA pattern2;
	TGA text;
	TGA part3;
	ReadTGAFile(pattern2, "input/pattern2.tga");
	ReadTGAFile(text, "input/text.tga");
	Multiply(layer1, pattern2, part3);
	Screen(text, part3, part3);
	WriteTGAFile(part3, "output/part3.tga");
	//part 4
	TGA cirlcles;
	TGA part4;
	ReadTGAFile(cirlcles, "input/circles.tga");
	Multiply(layer2, cirlcles, part4);
	Subtract(pattern2, part4, part4);
	WriteTGAFile(part4, "output/part4.tga");
	//part 5
	TGA part5;
	Overlay(layer1, pattern1, part5);
	WriteTGAFile(part5, "output/part5.tga");
	//part6
	TGA part6;
	AddToChannel(car, part6, "green", 200);
	WriteTGAFile(part6, "output/part6.tga");
	//part7
	TGA part7;
	ScaleChannel(car, part7, "red", 4);
	ScaleChannel(part7, part7, "blue", 0);
	WriteTGAFile(part7, "output/part7.tga");
	//Part 8
	TGA part8b;
	TGA part8g;
	TGA part8r;
	SetChannelEqual(car, part8b, "blue");
	SetChannelEqual(car, part8g, "green");
	SetChannelEqual(car, part8r, "red");
	WriteTGAFile(part8b, "output/part8_b.tga");
	WriteTGAFile(part8g, "output/part8_g.tga");
	WriteTGAFile(part8r, "output/part8_r.tga");
	//Part 9
	TGA layer_blue;
	TGA layer_green;
	TGA layer_red;
	TGA part9;
	ReadTGAFile(layer_blue, "input/layer_blue.tga");
	ReadTGAFile(layer_green, "input/layer_green.tga");
	ReadTGAFile(layer_red, "input/layer_red.tga");
	BuildFromLayers(layer_blue, layer_green, layer_red, part9);
	WriteTGAFile(part9, "output/part9.tga");
	//part10
	TGA part10;
	ReadTGAFile(part10, "input/text2.tga");
	WriteReverse(part10, "output/part10.tga");
	//extra credit
	TGA extraCredit;
	CombineImages(text, pattern1, car, cirlcles, extraCredit);
	WriteTGAFile(extraCredit, "output/extracredit.tga");
}

